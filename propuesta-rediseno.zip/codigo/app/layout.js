import { Source_Serif_4, Instrument_Sans } from "next/font/google";
import "../components/globals.css";
import Header from "../components/Header";
import Footer from "../components/Footer";
import Link from "next/link";
import { LuCalendarCheck } from "react-icons/lu";

// Fuentes autoalojadas por next/font: sin peticiones a Google en tiempo de
// ejecución, sin bloqueo de render y sin saltos de layout.
const serif = Source_Serif_4({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-serif",
  axes: ["opsz"], // tamaño óptico: el serif se ajusta solo en títulos grandes
});

const sans = Instrument_Sans({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-sans",
});

export const metadata = {
  title: "Jorge Valdez Rivera N.C. | Nutrición Clínica y Tanatología",
  description: "Cuidado metabólico, psicológico y emocional en la Ciudad de México.",
  icons: {
    icon: "/favicon.ico",
  },
};

export const viewport = {
  themeColor: "#ffffff",
};

export default function RootLayout({ children }) {
  return (
    <html lang="es" className={`${serif.variable} ${sans.variable}`}>
      <body>
        <a href="#contenido" className="skip-link">
          Saltar al contenido
        </a>
        <Header />

        <main id="contenido">{children}</main>

        <Footer />

        <Link href="/#contact" className="floating-cta" aria-label="Agendar Cita">
          <LuCalendarCheck aria-hidden="true" />
          <span>Agenda tu cita</span>
        </Link>
      </body>
    </html>
  );
}
