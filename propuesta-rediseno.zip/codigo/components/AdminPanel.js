// components/AdminPanel.js
"use client";
import { useCallback, useEffect, useState } from "react";
import { LuCheck, LuX, LuLogOut, LuClipboardList } from "react-icons/lu";
import { loadAuth, loadFirestore, isAdminUser } from "../Firebase";
import AdminLogin from "./AdminLogin";
import { ReviewItem } from "./ReviewForm";
import "./ReviewForm.css";
import "./AdminPanel.css";

const AdminPanel = () => {
  const [pendingReviews, setPendingReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [actionError, setActionError] = useState("");
  const [busyId, setBusyId] = useState(null);
  const [authState, setAuthState] = useState({ checking: true, isAdmin: false, denied: false });

  // Verificar sesión. La seguridad real está en firestore.rules;
  // aquí solo se decide qué interfaz mostrar.
  useEffect(() => {
    let unsub = () => {};
    let alive = true;
    loadAuth().then(({ auth, fa }) => {
      if (!alive) return;
      unsub = fa.onAuthStateChanged(auth, async (user) => {
        if (user && !isAdminUser(user)) {
          await fa.signOut(auth);
          setAuthState({ checking: false, isAdmin: false, denied: true });
          return;
        }
        setAuthState({ checking: false, isAdmin: Boolean(user), denied: false });
      });
    });
    return () => {
      alive = false;
      unsub();
    };
  }, []);

  const fetchPending = useCallback(async () => {
    try {
      const { db, fs } = await loadFirestore();
      const q = fs.query(
        fs.collection(db, "reviews"),
        fs.where("approved", "==", false),
        fs.where("rejected", "==", false)
      );
      const snap = await fs.getDocs(q);
      setPendingReviews(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
    } catch (err) {
      console.error("Error fetching pending reviews:", err);
      setError("Error al cargar reseñas pendientes.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (authState.isAdmin) fetchPending();
  }, [authState.isAdmin, fetchPending]);

  const moderate = async (reviewId, approve) => {
    if (!approve && !window.confirm("¿Seguro que deseas rechazar esta reseña?")) return;
    setBusyId(reviewId);
    setActionError("");
    try {
      const { db, fs } = await loadFirestore();
      await fs.updateDoc(fs.doc(db, "reviews", reviewId), {
        approved: approve,
        rejected: !approve,
      });
      setPendingReviews((prev) => prev.filter((r) => r.id !== reviewId));
    } catch (err) {
      console.error("Error moderating review:", err);
      setActionError(approve ? "Error al aprobar. Intenta de nuevo." : "Error al rechazar.");
    } finally {
      setBusyId(null);
    }
  };

  const handleLogout = async () => {
    const { auth, fa } = await loadAuth();
    await fa.signOut(auth);
  };

  if (authState.checking) {
    return (
      <div className="ap-loading" aria-busy="true">
        <span className="spinner" aria-hidden="true" />
      </div>
    );
  }

  if (!authState.isAdmin) {
    return <AdminLogin initialError={authState.denied ? "Esta cuenta no tiene acceso al panel." : ""} />;
  }

  return (
    <section className="ap">
      <div className="ap-bar">
        <div className="wrap ap-bar-inner">
          <h1>
            <LuClipboardList aria-hidden="true" />
            Panel de Moderación
          </h1>
          <div className="ap-user">
            <span className="ap-badge">Administrador</span>
            <button type="button" className="btn btn-outline ap-logout" onClick={handleLogout}>
              <LuLogOut aria-hidden="true" /> Salir
            </button>
          </div>
        </div>
      </div>

      <div className="wrap ap-content">
        <h2 className="ap-title">Reseñas Pendientes de Aprobación</h2>

        <div aria-live="polite">
          {actionError && <p className="notice notice-error">{actionError}</p>}
        </div>

        {loading ? (
          <div className="ap-state">
            <span className="spinner" aria-hidden="true" />
            <p>Cargando reseñas...</p>
          </div>
        ) : error ? (
          <p className="notice notice-error">{error}</p>
        ) : pendingReviews.length === 0 ? (
          <div className="ap-state">
            <span className="ap-done" aria-hidden="true">
              <LuCheck />
            </span>
            <h3>¡Todo al día!</h3>
            <p>No hay reseñas pendientes de moderación.</p>
          </div>
        ) : (
          <ul className="ap-list">
            {pendingReviews.map((review) => (
              <li key={review.id} className="ap-row">
                <ul className="ap-review">
                  <ReviewItem r={review} />
                </ul>
                <div className="ap-side">
                  <span className="ap-date">
                    {review.createdAt?.toDate
                      ? review.createdAt.toDate().toLocaleDateString("es-MX")
                      : "Reciente"}
                  </span>
                  <div className="ap-actions">
                    <button
                      type="button"
                      className="btn btn-outline ap-reject"
                      onClick={() => moderate(review.id, false)}
                      disabled={busyId === review.id}
                    >
                      <LuX aria-hidden="true" /> Rechazar
                    </button>
                    <button
                      type="button"
                      className="btn btn-primary"
                      onClick={() => moderate(review.id, true)}
                      disabled={busyId === review.id}
                    >
                      <LuCheck aria-hidden="true" /> Aprobar
                    </button>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </section>
  );
};

export default AdminPanel;
