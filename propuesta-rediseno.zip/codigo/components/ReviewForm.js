"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { LuUser } from "react-icons/lu";
import { FaGoogle } from "react-icons/fa";
import { loadAuth, loadFirestore } from "../Firebase";
import { StarsDisplay, StarsInput } from "./Stars";
import "./ReviewForm.css";

const NAME_MAX = 60;
const COMMENT_MAX = 1000;

export function ReviewItem({ r }) {
  return (
    <li className="rv-item">
      <div className="rv-item-head">
        <span className="rv-avatar">
          {r.photoURL ? (
            // Avatar remoto de Google: <img> simple, sin enviar referrer
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={r.photoURL}
              alt=""
              width={40}
              height={40}
              loading="lazy"
              referrerPolicy="no-referrer"
            />
          ) : (
            <LuUser aria-hidden="true" />
          )}
        </span>
        <div className="rv-meta">
          <span className="rv-name">{r.name}</span>
          <StarsDisplay value={r.rating} size={15} />
        </div>
        {r.provider === "google" && (
          <span className="rv-verified" title="Verificado por Google">
            <FaGoogle aria-hidden="true" />
            <span className="visually-hidden">Verificado por Google</span>
          </span>
        )}
      </div>
      <blockquote className="rv-quote">
        <p>{r.comment}</p>
      </blockquote>
    </li>
  );
}

const ReviewForm = () => {
  const sectionRef = useRef(null);
  const [reviews, setReviews] = useState([]);
  const [status, setStatus] = useState("idle"); // idle | loading | ready | error
  const [user, setUser] = useState(null);
  const [name, setName] = useState("");
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");
  const [website, setWebsite] = useState(""); // campo trampa
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  // Firestore se descarga solo cuando la sección se acerca a la pantalla,
  // y se piden 3 reseñas (antes: escucha en tiempo real de TODAS las reseñas).
  const fetchLatest = useCallback(async () => {
    setStatus("loading");
    try {
      const { db, fs } = await loadFirestore();
      const q = fs.query(
        fs.collection(db, "reviews"),
        fs.where("approved", "==", true),
        fs.orderBy("createdAt", "desc"),
        fs.limit(3)
      );
      const snap = await fs.getDocs(q);
      setReviews(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
      setStatus("ready");
    } catch (err) {
      console.error("Error fetching reviews:", err);
      setStatus("error");
    }
  }, []);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    if (!("IntersectionObserver" in window)) {
      const t = setTimeout(fetchLatest, 0);
      return () => clearTimeout(t);
    }
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          io.disconnect();
          fetchLatest();
        }
      },
      { rootMargin: "600px 0px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [fetchLatest]);

  // Precarga Auth al acercar el puntero: así el popup de Google se abre
  // dentro del gesto del usuario y no lo bloquea el navegador.
  const warmAuth = () => {
    loadAuth().catch(() => {});
  };

  const handleGoogleSignIn = async () => {
    setError("");
    try {
      const { auth, fa } = await loadAuth();
      const { user: u } = await fa.signInWithPopup(auth, new fa.GoogleAuthProvider());
      setUser(u);
      setName((u.displayName || "").slice(0, NAME_MAX));
    } catch (err) {
      if (err?.code === "auth/popup-closed-by-user") return;
      console.error("Google sign in error:", err);
      setError("Error al iniciar sesión con Google.");
    }
  };

  const cleanName = name.trim().slice(0, NAME_MAX);
  const cleanComment = comment.trim().slice(0, COMMENT_MAX);
  const isFormValid = cleanName.length >= 2 && rating >= 1 && rating <= 5 && cleanComment.length >= 5;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!isFormValid || isLoading) return;
    if (website) {
      setSubmitted(true);
      return;
    }
    setIsLoading(true);
    try {
      const { db, fs } = await loadFirestore();
      const isGoogle = Boolean(user);
      await fs.addDoc(fs.collection(db, "reviews"), {
        name: cleanName,
        rating,
        comment: cleanComment,
        approved: false,
        rejected: false,
        createdAt: fs.serverTimestamp(),
        photoURL: isGoogle ? user.photoURL || null : null,
        provider: isGoogle ? "google" : "email",
        uid: isGoogle ? user.uid : null,
      });
      setSubmitted(true);
      setRating(0);
      setComment("");
      setError("");
    } catch (err) {
      console.error("Error submitting review:", err);
      setError("Error al enviar la reseña. Inténtalo de nuevo.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section id="reviewform" className="rv" ref={sectionRef}>
      <div className="wrap">
        <header className="rv-head">
          <h2 className="section-title">Opiniones de nuestros pacientes</h2>
          <p className="section-lede">Tu salud y satisfacción son nuestra prioridad</p>
        </header>

        <div className="rv-grid">
          <div className="rv-panel">
            {!submitted ? (
              <>
                <h3 className="rv-panel-title">Comparte tu experiencia</h3>
                <p className="rv-panel-sub">Tu opinión nos ayuda a mejorar cada día.</p>

                {!user ? (
                  <button
                    type="button"
                    onClick={handleGoogleSignIn}
                    onPointerEnter={warmAuth}
                    onFocus={warmAuth}
                    className="btn btn-outline rv-google"
                  >
                    <FaGoogle aria-hidden="true" />
                    Continuar con Google
                  </button>
                ) : (
                  <div className="rv-user">
                    {user.photoURL ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={user.photoURL} alt="" width={32} height={32} referrerPolicy="no-referrer" />
                    ) : (
                      <LuUser aria-hidden="true" />
                    )}
                    <span>{user.displayName}</span>
                  </div>
                )}

                <p className="rv-divider">
                  <span>{user ? "Detalles de tu reseña" : "o escribe manualmente"}</span>
                </p>

                <form onSubmit={handleSubmit} className="rv-form">
                  {!user && (
                    <div className="field">
                      <label htmlFor="rv-name">Tu Nombre</label>
                      <input
                        id="rv-name"
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        autoComplete="name"
                        maxLength={NAME_MAX}
                        required
                      />
                    </div>
                  )}

                  <StarsInput value={rating} onChange={setRating} />

                  <div className="field">
                    <label htmlFor="rv-comment">Escribe tu comentario...</label>
                    <textarea
                      id="rv-comment"
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      rows={4}
                      maxLength={COMMENT_MAX}
                      required
                    />
                    <span className="field-hint">
                      {comment.length}/{COMMENT_MAX}
                    </span>
                  </div>

                  <div className="hp-field" aria-hidden="true">
                    <label htmlFor="rv-website">Sitio web</label>
                    <input
                      id="rv-website"
                      type="text"
                      tabIndex={-1}
                      autoComplete="off"
                      value={website}
                      onChange={(e) => setWebsite(e.target.value)}
                    />
                  </div>

                  <div aria-live="polite">{error && <p className="notice notice-error">{error}</p>}</div>

                  <button
                    type="submit"
                    className="btn btn-primary rv-submit"
                    disabled={!isFormValid || isLoading}
                  >
                    {isLoading ? "Enviando..." : "Publicar Opinión"}
                  </button>
                </form>
              </>
            ) : (
              <div className="rv-success" role="status">
                <h3 className="rv-panel-title">¡Gracias por tu opinión!</h3>
                <p>Tu reseña ha sido enviada y está pendiente de moderación para ser publicada.</p>
                <button type="button" onClick={() => setSubmitted(false)} className="btn btn-outline">
                  Escribir otra
                </button>
              </div>
            )}
          </div>

          <div className="rv-feed">
            <div className="rv-feed-head">
              <h3>Últimas Reseñas</h3>
              <Link href="/reviews">Ver todas</Link>
            </div>

            {(status === "idle" || status === "loading") && (
              <ul className="rv-list" aria-busy="true">
                {[0, 1, 2].map((i) => (
                  <li key={i} className="rv-item rv-skeleton" aria-hidden="true">
                    <span />
                    <span />
                    <span />
                  </li>
                ))}
              </ul>
            )}

            {status === "error" && (
              <p className="notice notice-error">No se pudieron cargar las reseñas.</p>
            )}

            {status === "ready" &&
              (reviews.length ? (
                <ul className="rv-list">
                  {reviews.map((r) => (
                    <ReviewItem key={r.id} r={r} />
                  ))}
                </ul>
              ) : (
                <p className="rv-empty">Aún no hay reseñas publicadas. ¡Sé el primero!</p>
              ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ReviewForm;
