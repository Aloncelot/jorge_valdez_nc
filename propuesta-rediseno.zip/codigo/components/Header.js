"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { LuMenu, LuX } from "react-icons/lu";
import "./Header.css";

const navLinks = [
  { href: "/#hero", text: "Inicio" },
  { href: "/#about", text: "Acerca de Mí" },
  { href: "/#services", text: "Servicios" },
  { href: "/#reviewform", text: "Testimonios" },
];

const Header = () => {
  const [open, setOpen] = useState(false);
  const [hidden, setHidden] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const lastY = useRef(0);
  const ticking = useRef(false);
  const toggleRef = useRef(null);
  const firstLinkRef = useRef(null);

  // Un solo listener pasivo + requestAnimationFrame (antes se volvía a
  // registrar en cada evento de scroll).
  useEffect(() => {
    const update = () => {
      const y = window.scrollY;
      setHidden(y > lastY.current && y > 160);
      setScrolled(y > 8);
      lastY.current = y;
      ticking.current = false;
    };
    const onScroll = () => {
      if (!ticking.current) {
        ticking.current = true;
        requestAnimationFrame(update);
      }
    };
    const raf = requestAnimationFrame(update);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("scroll", onScroll);
    };
  }, []);

  // Menú móvil: bloquear scroll, Escape para cerrar, foco al primer enlace
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    firstLinkRef.current?.focus();
    const onKey = (e) => {
      if (e.key === "Escape") {
        setOpen(false);
        toggleRef.current?.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const close = () => setOpen(false);
  const closeAndReturn = () => {
    setOpen(false);
    toggleRef.current?.focus();
  };

  return (
    <>
      <header
        className="hdr"
        data-hidden={hidden && !open ? "" : undefined}
        data-scrolled={scrolled ? "" : undefined}
      >
        <div className="wrap hdr-inner">
          <Link href="/" className="hdr-brand">
            Jorge Valdez Rivera <span className="hdr-post">N.C.</span>
          </Link>

          <nav className="hdr-nav" aria-label="Principal">
            <ul>
              {navLinks.map((link) => (
                <li key={link.href}>
                  <Link href={link.href}>{link.text}</Link>
                </li>
              ))}
            </ul>
          </nav>

          <Link href="/#contact" className="btn btn-primary hdr-cta">
            Agenda tu cita
          </Link>

          <button
            ref={toggleRef}
            type="button"
            className="hdr-toggle"
            aria-expanded={open}
            aria-controls="menu-movil"
            aria-label="Abrir menú"
            onClick={() => setOpen(true)}
          >
            <LuMenu aria-hidden="true" />
          </button>
        </div>
      </header>

      {/* Fuera del <header>: su backdrop-filter crearía un contenedor para position:fixed */}
      <div className="hdr-overlay" data-open={open ? "" : undefined} onClick={closeAndReturn} aria-hidden="true" />

      <div
        id="menu-movil"
        className="hdr-drawer"
        data-open={open ? "" : undefined}
        inert={!open}
        role="dialog"
        aria-modal="true"
        aria-label="Menú"
      >
        <div className="hdr-drawer-top">
          <span className="hdr-brand">
            Jorge Valdez Rivera <span className="hdr-post">N.C.</span>
          </span>
          <button type="button" className="hdr-toggle hdr-close" aria-label="Cerrar menú" onClick={closeAndReturn}>
            <LuX aria-hidden="true" />
          </button>
        </div>
        <ul className="hdr-drawer-links">
          {navLinks.map((link, i) => (
            <li key={link.href}>
              <Link href={link.href} onClick={close} ref={i === 0 ? firstLinkRef : undefined}>
                {link.text}
              </Link>
            </li>
          ))}
        </ul>
        <Link href="/#contact" className="btn btn-primary hdr-drawer-cta" onClick={close}>
          Agenda tu cita
        </Link>
        <Link href="/admin-login" className="hdr-drawer-admin" onClick={close}>
          Acceso Admin
        </Link>
      </div>
    </>
  );
};

export default Header;
