// components/About.js — Server Component
import Link from "next/link";
import "./About.css";

const About = () => {
  return (
    <section id="about" className="about">
      <div className="wrap about-grid">
        <header className="about-head">
          <h2 className="section-title">Acerca de Mí</h2>
          <p className="about-name">Jorge Valdez Rivera N.C.</p>
          <p className="about-role">Nutricionista Certificado</p>
        </header>

        <div className="about-body">
          <p className="about-statement">
            Nuestra filosofía es cuidar de ti <strong>metabólicamente</strong>,
            <strong> psicológicamente</strong> y <strong>emocionalmente</strong>.
          </p>
          <p className="about-text">
            Mi objetivo es llevar al máximo tu metabolismo, trabajando siempre en armonía con tus
            emociones para lograr resultados sostenibles sin afectaciones clínicas.
          </p>

          <Link href="/about" className="btn btn-outline about-link">
            Conocer mi trayectoria
          </Link>
        </div>
      </div>
    </section>
  );
};

export default About;
