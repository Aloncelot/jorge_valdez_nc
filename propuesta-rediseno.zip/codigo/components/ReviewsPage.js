// components/ReviewsPage.js
"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { LuArrowLeft } from "react-icons/lu";
import { loadFirestore } from "../Firebase";
import { ReviewItem } from "./ReviewForm";
import "./ReviewForm.css";
import "./ReviewsPage.css";

const PER_PAGE = 8;

const ReviewsPage = () => {
  const [reviews, setReviews] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [status, setStatus] = useState("loading");

  // Lectura única (getDocs) en lugar de una escucha en tiempo real.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const { db, fs } = await loadFirestore();
        const q = fs.query(
          fs.collection(db, "reviews"),
          fs.where("approved", "==", true),
          fs.orderBy("createdAt", "desc")
        );
        const snap = await fs.getDocs(q);
        if (cancelled) return;
        setReviews(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
        setStatus("ready");
      } catch (err) {
        console.error("Error fetching reviews: ", err);
        if (!cancelled) setStatus("error");
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const totalPages = Math.ceil(reviews.length / PER_PAGE);
  const start = (currentPage - 1) * PER_PAGE;
  const currentReviews = reviews.slice(start, start + PER_PAGE);

  const paginate = (n) => {
    setCurrentPage(n);
    document.getElementById("testimonios")?.scrollIntoView({ block: "start" });
  };

  return (
    <section id="testimonios" className="rp">
      <div className="wrap">
        <header className="rp-head">
          <h1 className="section-title">Testimonios de Pacientes</h1>
          <p className="section-lede">Lo que dicen quienes han confiado en nosotros</p>
        </header>

        {status === "loading" && (
          <div className="rp-loading" aria-busy="true">
            <span className="spinner" aria-hidden="true" />
            <span className="visually-hidden">Cargando</span>
          </div>
        )}

        {status === "error" && (
          <p className="notice notice-error rp-notice">No se pudieron cargar las reseñas.</p>
        )}

        {status === "ready" && reviews.length === 0 && (
          <p className="rv-empty">Aún no hay reseñas publicadas. ¡Sé el primero!</p>
        )}

        {status === "ready" && reviews.length > 0 && (
          <>
            <ul className="rp-grid">
              {currentReviews.map((r) => (
                <ReviewItem key={r.id} r={r} />
              ))}
            </ul>

            {totalPages > 1 && (
              <nav className="rp-pages" aria-label="Paginación">
                {Array.from({ length: totalPages }, (_, i) => (
                  <button
                    key={i}
                    type="button"
                    className="rp-page"
                    aria-current={i + 1 === currentPage ? "page" : undefined}
                    onClick={() => paginate(i + 1)}
                  >
                    {i + 1}
                  </button>
                ))}
              </nav>
            )}
          </>
        )}

        <Link href="/" className="btn btn-outline rp-back">
          <LuArrowLeft aria-hidden="true" /> Volver al Inicio
        </Link>
      </div>
    </section>
  );
};

export default ReviewsPage;
