// components/Maratones.js
// Antes: animación infinita de framer-motion con 27 tarjetas (3 copias),
// dos listeners de resize duplicados y desajuste de hidratación en móvil.
// Ahora: línea de tiempo con scroll nativo y snap; JS solo para los botones.
"use client";
import { useRef } from "react";
import Image from "next/image";
import { LuChevronLeft, LuChevronRight } from "react-icons/lu";
import img2019 from "../public/2019.webp";
import imgGlobal from "../public/abbott-world-marathon-majors-launches-global-run-club.webp";
import imgChicago from "../public/CH Marathon.jpg";
import img2021 from "../public/2021.jpg";
import img2022 from "../public/2022.png";
import img2023 from "../public/2023.png";
import imgTokyo from "../public/Tokyo Marathon.jpg";
import img2024 from "../public/2024.png";
import imgBerlin from "../public/berlin_logo.svg";
import imgWMM from "../public/World-Marathon-Majors.jpg";
import "./Maratones.css";

const marathonsData = [
  { title: "Edición XXXVII del Maratón de la Ciudad de México", date: "Agosto 2019", image: img2019 },
  {
    title: "Abbott WMM Global Run Club Plataforma virtual",
    date: "Noviembre 2020",
    image: imgGlobal,
    wmm: true,
  },
  {
    title: "Abbot World Marathon Majors Maratón de Chicago",
    date: "Octubre 2021",
    image: imgChicago,
    wmm: true,
  },
  { title: "Edición XXXVIII MARATÓN DE LA CIUDAD DE MÉXICO", date: "Noviembre 2021", image: img2021 },
  { title: "Edición XXXIX MARATÓN DE LA CIUDAD DE MÉXICO", date: "Agosto 2022", image: img2022 },
  { title: "Edición XL MARATÓN DE LA CIUDAD DE MÉXICO", date: "Agosto 2023", image: img2023 },
  {
    title: "Abbott World Marathon Majors Maratón de Tokio",
    date: "Marzo 2024",
    image: imgTokyo,
    wmm: true,
  },
  { title: "Edición XLI MARATÓN DE LA CIUDAD DE MÉXICO", date: "Agosto 2024", image: img2024 },
  { title: "Berlín Marathon 2025", date: "Septiembre 2025", image: imgBerlin, wmm: true },
];

const Maratones = () => {
  const trackRef = useRef(null);

  const scrollByCard = (dir) => {
    const track = trackRef.current;
    if (!track) return;
    const card = track.querySelector("li");
    const step = card ? card.getBoundingClientRect().width + 24 : 320;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    track.scrollBy({ left: dir * step, behavior: reduce ? "auto" : "smooth" });
  };

  return (
    <section id="maratones" className="mr">
      <div className="wrap mr-head">
        <div>
          <h2 className="section-title">Maratones</h2>
          <p className="section-lede">Maratones en los que he participado</p>
        </div>
        <div className="mr-controls">
          <button type="button" onClick={() => scrollByCard(-1)} aria-label="Maratón anterior">
            <LuChevronLeft aria-hidden="true" />
          </button>
          <button type="button" onClick={() => scrollByCard(1)} aria-label="Maratón siguiente">
            <LuChevronRight aria-hidden="true" />
          </button>
        </div>
      </div>

      <ol className="mr-track" ref={trackRef} tabIndex={0} aria-label="Línea de tiempo de maratones">
        {marathonsData.map((m) => (
          <li key={m.title + m.date} className="mr-item">
            <p className="mr-date">
              <time>{m.date}</time>
            </p>
            <div className="mr-media">
              <Image src={m.image} alt={m.title} sizes="300px" />
            </div>
            {m.wmm && (
              <Image
                src={imgWMM}
                alt="Abbott World Marathon Majors"
                className="mr-wmm"
                sizes="120px"
              />
            )}
            <h3>{m.title}</h3>
          </li>
        ))}
      </ol>
    </section>
  );
};

export default Maratones;
