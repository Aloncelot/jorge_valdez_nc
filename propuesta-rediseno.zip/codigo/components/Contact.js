// components/Contact.js — Server Component
// Solo el formulario y los mapas son interactivos (componentes cliente).
import Image from "next/image";
import { LuPhone, LuMessageCircle, LuMail, LuClock, LuMapPin } from "react-icons/lu";
import ContactForm from "./ContactForm";
import MapFacade from "./MapFacade";
import logoStar from "../public/LogoStarMedica2.png";
import logoAngeles from "../public/HAM.png";
import { EMAIL, PHONES, WHATSAPP_URL } from "./siteData";
import "./Contact.css";

const locations = [
  {
    title: "Hospital Star Médica Luna Parc",
    mapSrc:
      "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3757.2877094961746!2d-99.21322532405416!3d19.657727133451438!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d21e3669cad269%3A0xdb9ee0f3be58b530!2sHospital%20Star%20M%C3%A9dica%20Luna%20Parc!5e0!3m2!1ses-419!2smx!4v1772164989723!5m2!1ses-419!2smx",
    logo: logoStar,
    address:
      "Av. Primero de Mayo s/n. Col. Centro Urbano, Cuautitlán Izcalli. Consultorio 1418 Piso 14",
  },
  {
    title: "Hospital Star Médica Tlalnepantla",
    mapSrc:
      "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d60161.6169979666!2d-99.28155630826953!3d19.537274256247787!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d21dae2a60a465%3A0xd8d0e8a8fa4a5162!2sHospital%20Star%20M%C3%A9dica%20Tlalnepantla!5e0!3m2!1ses-419!2smx!4v1772164602588!5m2!1ses-419!2smx",
    logo: logoStar,
    address:
      "Av Sor Juana Inés de La Cruz 280, Fracc. Industrial, San Lorenzo, 54033 Tlalnepantla, Méx. Consultorio 903",
  },
  {
    title: "Hospital Angeles Mocel",
    mapSrc:
      "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3763.0339371638706!2d-99.1847803!3d19.410939600000003!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d1ff5e9cb14657%3A0xed4a8855e9a5502f!2sHospital%20Angeles%20Mocel!5e0!3m2!1ses-419!2smx!4v1772165041457!5m2!1ses-419!2smx",
    logo: logoAngeles,
    logoClass: "ct-loc-logo--tall",
    address: "Torre Médica Mocel, Gelati 33, San Miguel Chapultepec. Consultorio 202",
  },
];

const Contact = () => {
  return (
    <section id="contact" className="ct">
      <div className="wrap">
        <header className="ct-head">
          <h2 className="section-title">Contacto y Citas</h2>
          <p className="section-lede">Agenda tu consulta o envíanos tus dudas</p>
        </header>

        <div className="ct-grid">
          <div className="ct-panel">
            <h3 className="ct-panel-title">Envíanos un mensaje</h3>
            <ContactForm />
          </div>

          <div className="ct-info">
            <h3 className="ct-panel-title">Información Directa</h3>
            <dl className="ct-list">
              <div className="ct-item">
                <LuPhone aria-hidden="true" />
                <dt>Citas y Urgencias</dt>
                <dd>
                  {PHONES.map((p) => (
                    <a key={p.href} href={p.href} className="ct-num">
                      {p.label}
                    </a>
                  ))}
                </dd>
              </div>
              <div className="ct-item">
                <LuMessageCircle aria-hidden="true" />
                <dt>WhatsApp</dt>
                <dd>
                  <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer">
                    Enviar mensaje directo
                  </a>
                </dd>
              </div>
              <div className="ct-item">
                <LuMail aria-hidden="true" />
                <dt>Correo Electrónico</dt>
                <dd>
                  <a href={`mailto:${EMAIL}`}>{EMAIL}</a>
                </dd>
              </div>
              <div className="ct-item">
                <LuClock aria-hidden="true" />
                <dt>Horario de Atención</dt>
                <dd>Lunes a Sábado (Previa Cita)</dd>
              </div>
            </dl>
          </div>
        </div>

        <div className="ct-locs">
          <h3 className="ct-locs-title">Nuestras Ubicaciones</h3>
          <ul className="ct-locs-grid">
            {locations.map((loc) => (
              <li key={loc.title} className="ct-loc">
                <MapFacade title={loc.title} src={loc.mapSrc} />
                <div className="ct-loc-body">
                  <Image
                    src={loc.logo}
                    alt={`${loc.title} Logo`}
                    className={`ct-loc-logo ${loc.logoClass || ""}`}
                    sizes="160px"
                  />
                  <h4>{loc.title}</h4>
                  <p>{loc.address}</p>
                  <a
                    href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(loc.title)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="ct-loc-link"
                  >
                    <LuMapPin aria-hidden="true" /> Ver en Mapa
                  </a>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
};

export default Contact;
