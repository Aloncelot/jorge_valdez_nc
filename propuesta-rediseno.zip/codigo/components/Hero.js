// components/Hero.js — Server Component (cero JS en el cliente)
import Image from "next/image";
import { LuCalendarCheck, LuPhone } from "react-icons/lu";
import portrait from "../public/JorgeValdez.webp";
import { CREDENTIALS, PHONES } from "./siteData";
import "./Hero.css";

const Hero = () => {
  return (
    <section id="hero" className="hero">
      <div className="wrap hero-grid">
        <div className="hero-copy">
          <h1 className="hero-name">
            Jorge Valdez Rivera <span className="hero-post">N.C.</span>
          </h1>

          <p className="hero-fields">
            Nutrición Clínica <span className="hero-sep">/</span> Tanatología{" "}
            <span className="hero-sep">/</span> Ciencias del Comportamiento Humano
          </p>

          <div className="hero-actions">
            <a href="#contact" className="btn btn-primary">
              <LuCalendarCheck aria-hidden="true" />
              Agenda tu cita
            </a>
            <a href={PHONES[0].href} className="hero-phone">
              <LuPhone aria-hidden="true" />
              {PHONES[0].label}
            </a>
          </div>
        </div>

        <figure className="hero-portrait">
          <Image
            src={portrait}
            alt="Nutricionista Jorge Valdez"
            preload
            placeholder="blur"
            sizes="(max-width: 899px) 100vw, 420px"
          />
        </figure>
      </div>

      {/* Curva metabólica: oscila y se estabiliza. Se dibuja una sola vez. */}
      <svg
        className="hero-curve"
        viewBox="0 0 1440 120"
        preserveAspectRatio="none"
        aria-hidden="true"
        focusable="false"
      >
        <path
          pathLength="1"
          d="M0 70 C 40 70, 60 22, 96 22 S 150 104, 196 104 S 250 34, 292 38 S 350 88, 392 86 S 452 52, 500 56 S 572 74, 624 72 S 720 62, 790 63 S 920 66, 1010 65 L 1440 65"
        />
        <circle cx="1010" cy="65" r="5" />
      </svg>

      <div className="wrap hero-creds">
        <h2 className="hero-creds-title">Certificaciones y Cédulas</h2>
        <ul>
          {CREDENTIALS.map((c) => (
            <li key={c}>{c}</li>
          ))}
        </ul>
      </div>
    </section>
  );
};

export default Hero;
