// components/Footer.js — Server Component
import Link from "next/link";
import { LuPhone, LuMail, LuLock, LuTerminal } from "react-icons/lu";
import { FaFacebookF, FaWhatsapp } from "react-icons/fa";
import { EMAIL, FACEBOOK_URL, PHONES, WHATSAPP_URL } from "./siteData";
import "./Footer.css";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="ft">
      <div className="wrap ft-grid">
        <div className="ft-brand">
          <p className="ft-logo">Jorge Valdez Rivera N.C.</p>
          <p className="ft-mission">
            Comprometido con tu salud a través de planes nutricionales personalizados y basados en
            ciencia.
          </p>
          <div className="ft-social">
            <a href={FACEBOOK_URL} target="_blank" rel="noopener noreferrer" aria-label="Facebook">
              <FaFacebookF aria-hidden="true" />
            </a>
            <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer" aria-label="WhatsApp">
              <FaWhatsapp aria-hidden="true" />
            </a>
          </div>
        </div>

        <nav className="ft-col" aria-label="Explorar">
          <h2>Explorar</h2>
          <ul>
            <li>
              <Link href="/">Inicio</Link>
            </li>
            <li>
              <Link href="/about">Acerca de mi</Link>
            </li>
            <li>
              <Link href="/reviews">Testimonios</Link>
            </li>
          </ul>
        </nav>

        <div className="ft-col">
          <h2>Contacto</h2>
          <ul>
            <li>
              <LuPhone aria-hidden="true" />
              <a href={PHONES[0].href}>(55) 5437-3485</a>
            </li>
            <li>
              <LuMail aria-hidden="true" />
              <a href={`mailto:${EMAIL}`}>{EMAIL}</a>
            </li>
          </ul>
        </div>
      </div>

      <div className="wrap">
        <div className="ft-bottom">
        <p>&copy; {currentYear} Jorge Valdez Rivera N.C. Todos los derechos reservados.</p>
        <div className="ft-bottom-links">
          <a href="https://quasar-devs.vercel.app/" target="_blank" rel="noopener noreferrer">
            <LuTerminal aria-hidden="true" />
            Built by QUASAR DEVS
          </a>
          <Link href="/admin-login" rel="nofollow">
            <LuLock aria-hidden="true" />
            Admin
          </Link>
        </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
