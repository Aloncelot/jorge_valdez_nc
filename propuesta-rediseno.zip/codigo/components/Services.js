// components/Services.js — Server Component
// Antes: carrusel con framer-motion que mostraba 1 de 5 servicios y
// re-cargaba la imagen con spinner en cada clic. Ahora: lista completa,
// imágenes optimizadas y diferidas, sin JavaScript.
import Image from "next/image";
import imgNutricion from "../public/Nutricionintra.webp";
import imgDeportivo from "../public/asesoramientodeportivo.webp";
import imgMetabolico from "../public/controlmetabolico.webp";
import imgCritico from "../public/NEP.webp";
import imgTanatologia from "../public/tntg.webp";
import "./Services.css";

const servicesData = [
  {
    title: "Nutrición Clínica",
    description:
      "Soporte Nutricional Artificial Específico, Nutrición Enteral y Parenteral para pacientes hospitalizados o en casa.",
    image: imgNutricion,
  },
  {
    title: "Asesoramiento Deportivo",
    description:
      "Estrategias de suplementación y nutrición basadas en marcadores bioquímicos para maximizar el rendimiento.",
    image: imgDeportivo,
  },
  {
    title: "Control Metabólico",
    description:
      "Programas clínicos efectivos para la pérdida de peso saludable, sostenible y prevención de enfermedades.",
    image: imgMetabolico,
  },
  {
    title: "Nutrición en Estado Crítico",
    description:
      "Manejo metabólico especializado para diversas patologías agudas y control de comorbilidades complejas.",
    image: imgCritico,
  },
  {
    title: "Tanatología y Comportamiento",
    description:
      "Apoyo psicológico integral para afrontar pérdidas y situaciones difíciles, brindando soporte al paciente y su familia.",
    image: imgTanatologia,
  },
];

const Services = () => {
  return (
    <section id="services" className="svc">
      <div className="wrap svc-grid">
        <header className="svc-head">
          <h2 className="section-title">Nuestros Servicios</h2>
          <p className="section-lede">Atención integral basada en evidencia</p>
        </header>

        <ul className="svc-list">
          {servicesData.map((s) => (
            <li key={s.title} className="svc-item">
              <div className="svc-media">
                <Image
                  src={s.image}
                  alt={s.title}
                  placeholder="blur"
                  sizes="(max-width: 699px) 100vw, 260px"
                />
              </div>
              <div className="svc-copy">
                <h3>{s.title}</h3>
                <p>{s.description}</p>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
};

export default Services;
