// components/StudiesAtHome.js — Server Component
import Image from "next/image";
import {
  LuDroplet,
  LuFlaskConical,
  LuTestTube,
  LuMicroscope,
  LuDna,
  LuActivity,
  LuPhone,
} from "react-icons/lu";
import bagc from "../public/BAGC.jpg";
import { PHONES, WHATSAPP_URL } from "./siteData";
import "./StudiesAtHome.css";

const studiesData = [
  { title: "Biometría Hemática", Icon: LuDroplet },
  { title: "Química Sanguínea", Icon: LuFlaskConical },
  { title: "Hemoglobina Glucosilada", Icon: LuTestTube },
  { title: "Uroanálisis", Icon: LuMicroscope },
  { title: "Antígenos Tumorales", Icon: LuDna },
  { title: "Perfiles Hormonales", Icon: LuActivity },
];

const StudiesAtHome = () => {
  return (
    <section id="studiesathome" className="std">
      <div className="wrap">
        <header className="std-head">
          <h2 className="section-title">Estudios Clínicos a Domicilio</h2>
          <p className="section-lede">Comodidad y precisión diagnóstica sin salir de casa</p>
        </header>

        {/* Rejilla tipo orden de laboratorio */}
        <ul className="std-grid">
          {studiesData.map(({ title, Icon }) => (
            <li key={title} className="std-item">
              <Icon aria-hidden="true" />
              <h3>{title}</h3>
            </li>
          ))}
        </ul>

        <div className="std-more">
          <div className="std-more-copy">
            <h3>¿Necesitas otro estudio?</h3>
            <p>Contamos con un catálogo amplio. Pregunte por el que requiera.</p>
          </div>
          <div className="std-more-actions">
            <a href={PHONES[0].href} className="btn std-btn-light">
              <LuPhone aria-hidden="true" />
              {PHONES[0].label}
            </a>
            <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer" className="std-wa">
              WhatsApp
            </a>
          </div>
        </div>

        <div className="std-partner">
          <h3>En alianza con Laboratorios Certificados</h3>
          <div className="std-partner-logo">
            <Image src={bagc} alt="Laboratorio BAGC" sizes="240px" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default StudiesAtHome;
