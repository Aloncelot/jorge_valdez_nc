// components/AboutMe.js — Server Component
import Image from "next/image";
import Link from "next/link";
import { LuArrowLeft, LuGraduationCap, LuHospital, LuBadgeCheck } from "react-icons/lu";
import portrait from "../public/JorgeValdez.webp";
import { CREDENTIALS } from "./siteData";
import "./AboutMe.css";

const AboutMe = () => {
  return (
    <section id="about-me" className="am">
      <div className="wrap">
        <header className="am-head">
          <h1 className="section-title am-title">Trayectoria Profesional</h1>
          <p className="section-lede">Compromiso, Ciencia y Empatía</p>
        </header>

        <div className="am-grid">
          <figure className="am-figure">
            <div className="am-photo">
              <Image
                src={portrait}
                alt="Lic. Jorge Valdez Rivera"
                preload
                placeholder="blur"
                sizes="(max-width: 899px) 100vw, 420px"
              />
            </div>
            <figcaption className="am-badge">
              <span className="am-badge-years">+10 Años</span>
              <span className="am-badge-text">Experiencia Clínica</span>
            </figcaption>
          </figure>

          <div className="am-body">
            <h2 className="am-name">Jorge Valdez Rivera N.C.</h2>
            <p className="am-specialty">Nutrición Clínica &amp; Tanatología</p>

            <p className="am-intro">
              Nuestra filosofía es cuidar de ti <strong>metabólicamente</strong>,
              <strong> psicológicamente</strong> y <strong>emocionalmente</strong>. Mi enfoque busca
              llevar al máximo tu metabolismo en armonía con tus emociones, sin afectaciones clínicas.
            </p>

            <ul className="am-facts">
              <li>
                <LuGraduationCap aria-hidden="true" />
                <p>
                  Egresado de la <strong>Universidad Autónoma del Estado de México</strong>, Facultad
                  de Medicina (UAEM-Toluca).
                </p>
              </li>
              <li>
                <LuHospital aria-hidden="true" />
                <p>
                  Formación clínica de 5 años en Unidad de Terapia Intensiva,{" "}
                  <strong>Hospital Angeles Lomas</strong>.
                </p>
              </li>
              <li>
                <LuBadgeCheck aria-hidden="true" />
                <p>
                  El 90% de mis pacientes son referidos por especialistas médicos, garantizando un
                  manejo interdisciplinario de alto nivel.
                </p>
              </li>
            </ul>

            <div className="am-creds">
              <h3>Certificaciones y Cédulas</h3>
              <ul>
                {CREDENTIALS.map((c) => (
                  <li key={c}>{c}</li>
                ))}
              </ul>
            </div>

            <Link href="/" className="btn btn-outline am-back">
              <LuArrowLeft aria-hidden="true" />
              Volver al Inicio
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutMe;
