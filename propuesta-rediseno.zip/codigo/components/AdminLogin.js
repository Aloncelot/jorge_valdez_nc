"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { LuShieldCheck, LuArrowLeft } from "react-icons/lu";
import { FaGoogle } from "react-icons/fa";
import { loadAuth, isAdminUser } from "../Firebase";
import "./AdminLogin.css";

const NOT_ALLOWED = "Esta cuenta no tiene acceso al panel.";

const AdminLogin = ({ initialError = "" }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(initialError);
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const afterLogin = async (user, auth, fa) => {
    if (!isAdminUser(user)) {
      await fa.signOut(auth);
      setError(NOT_ALLOWED);
      return;
    }
    router.push("/admin");
  };

  const handleEmailLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const { auth, fa } = await loadAuth();
      const { user } = await fa.signInWithEmailAndPassword(auth, email.trim(), password);
      await afterLogin(user, auth, fa);
    } catch (err) {
      console.error("Firebase login error:", err?.code || err);
      setError("Credenciales incorrectas o acceso no autorizado.");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setLoading(true);
    setError("");
    try {
      const { auth, fa } = await loadAuth();
      const { user } = await fa.signInWithPopup(auth, new fa.GoogleAuthProvider());
      await afterLogin(user, auth, fa);
    } catch (err) {
      if (err?.code !== "auth/popup-closed-by-user") {
        console.error("Firebase Google login error:", err?.code || err);
        setError("Error al autenticar con Google.");
      }
    } finally {
      setLoading(false);
    }
  };

  const warmAuth = () => {
    loadAuth().catch(() => {});
  };

  return (
    <section className="al">
      <div className="al-card">
        <div className="al-head">
          <span className="al-icon">
            <LuShieldCheck aria-hidden="true" />
          </span>
          <h1>Panel de Administración</h1>
          <p>Acceso exclusivo para personal autorizado</p>
        </div>

        <form onSubmit={handleEmailLogin} className="al-form" onFocus={warmAuth}>
          <div className="field">
            <label htmlFor="al-email">Correo Electrónico</label>
            <input
              id="al-email"
              type="email"
              autoComplete="username"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div className="field">
            <label htmlFor="al-pass">Contraseña</label>
            <input
              id="al-pass"
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <div aria-live="assertive">{error && <p className="notice notice-error">{error}</p>}</div>

          <button type="submit" className="btn btn-primary al-submit" disabled={loading}>
            {loading ? "Verificando..." : "Ingresar al Panel"}
          </button>
        </form>

        <p className="al-divider">
          <span>o acceder con</span>
        </p>

        <button
          type="button"
          onClick={handleGoogleLogin}
          onPointerEnter={warmAuth}
          className="btn btn-outline al-google"
          disabled={loading}
        >
          <FaGoogle aria-hidden="true" />
          Google Admin
        </button>

        <Link href="/" className="al-back">
          <LuArrowLeft aria-hidden="true" /> Volver al Sitio Principal
        </Link>
      </div>
    </section>
  );
};

export default AdminLogin;
